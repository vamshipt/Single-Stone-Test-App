﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ContactWebApplication.Models
{
    public class ContactViewModel
    {
        public NameModel Names { get; set; }
        public AddressModel Address { get; set; }
        public PhoneModel Phones { get; set; }

        [Display(Name = "Email")]
        [EmailAddress]
        [RegularExpression(@"^([A-Za-z0-9][^'!&\\#*$%^?<>()+=:;`~\[\]{}|/,₹€@ ][a-zA-z0-9-._][^!&\\#*$%^?<>()+=:;`~\[\]{}|/,₹€@ ]*\@[a-zA-Z0-9][^!&@\\#*$%^?<>()+=':;~`.\[\]{}|/,₹€ ]*\.[a-zA-Z]{2,6})$", ErrorMessage = "Please enter a  valid Email")]
        [Required]
        public string Email { get; set; }
        public int? Id { get; set; }
    }
    public class NameModel
    {
        [Display(Name = "First Name")]
        [Required]
        public string FirstName { get; set; }
        [Display(Name = "Last Name")]
        [Required]
        public string LastName { get; set; }
        [Display(Name = "Middle Name")]
        public string MiddleName { get; set; }
    }
    public class AddressModel
    {
        [Display(Name = "Street")]
        [Required]
        public string Street { get; set; }
        [Display(Name = "City")]
        [Required]
        public string City { get; set; }
        [Display(Name = "State")]
        [Required]
        public string State { get; set; }
        [Display(Name = "Zip")]
        [Required]
        public string Zip { get; set; }
    }

    public class PhoneModel
    {
        [Required(ErrorMessage = "You must provide a phone number")]
        [DataType(DataType.PhoneNumber)]
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "Not a valid phone number")]
        [Display(Name = "Number")]
        public string Number { get; set; }
        [Display(Name = "Type")]
        public string Type { get; set; }
    }
}
