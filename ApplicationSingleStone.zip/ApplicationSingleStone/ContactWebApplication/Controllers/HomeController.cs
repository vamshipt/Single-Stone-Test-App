﻿using System.Collections.Generic;
using System.Net.Http;
using System.Web.Mvc;
using ContactWebApplication.Models;
using ContactWebApplication.WebServiceHelper;

namespace ContactWebApplication.Controllers
{
    public class HomeController : Controller
    {

        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Index(ContactViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            else
            {
                ServiceRepository repository = new ServiceRepository();
                HttpResponseMessage response = null;
                if (model.Id == 0 || model.Id == null)
                {
                    response = repository.PostResponse("/Post", model);
                    TempData["Result"] = "Contact saved successfully!";
                }
                else
                {
                    response = repository.PutResponse("/Put", model);
                    TempData["Result"] = "Contact updated successfully!";
                }

                if (response.IsSuccessStatusCode)
                {

                    return RedirectToAction("Index");
                }


            }
            return RedirectToAction("Index");
        }
        [HttpPut]
        [ValidateAntiForgeryToken]
        public ActionResult Update(ContactViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            else
            {
                ServiceRepository repository = new ServiceRepository();

                var result = repository.PutResponse("/Put", model);

                if (result.IsSuccessStatusCode)
                {
                    ViewBag.result = "Contact updated successfully!";
                    return RedirectToAction("Index");
                }
            }
            return RedirectToAction("Index");
        }

        [HttpGet]
        public ActionResult GetAllContacts()
        {
            ServiceRepository repository = new ServiceRepository();
            var result = repository.GetResponse("/Get");

            if (result.IsSuccessStatusCode)
            {
                var response = result.Content.ReadAsStringAsync().Result.Replace("\\", "")
                                               .Trim(new char[1] { '"' });
                List<ContactViewModel> contacts = new System.Web.Script.Serialization.JavaScriptSerializer().Deserialize<List<ContactViewModel>>(response);
                return View(contacts);
            }
            else return View();
        }
        [HttpGet]
        public ActionResult GetContact(int id)
        {
            ServiceRepository repository = new ServiceRepository();
            var result = repository.GetResponse("/Get?id=" + id.ToString());

            if (result.IsSuccessStatusCode)
            {
                var response = result.Content.ReadAsStringAsync().Result.Replace("\\", "")
                                               .Trim(new char[1] { '"' });
                ContactViewModel contacts = new System.Web.Script.Serialization.JavaScriptSerializer().Deserialize<ContactViewModel>(response);

                return View("Index", contacts);
            }
            else return RedirectToAction("GetAllContacts");
        }

        public ActionResult DeleteContact(int id)
        {
            ServiceRepository serviceObj = new ServiceRepository();
            var response = serviceObj.DeleteResponse("/Delete?id=" + id.ToString());
            response.EnsureSuccessStatusCode();
            return RedirectToAction("GetAllContacts");
        }
    }
}
