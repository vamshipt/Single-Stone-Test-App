﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Script.Serialization;

namespace ContactWebApplication.WebServiceHelper
{
    public class ServiceRepository
    {
        public HttpClient Client { get; set; }
        public ServiceRepository()
        {
            Client = new HttpClient();
            Client.BaseAddress = new Uri(ConfigurationManager.AppSettings["WebServicePath"]);
        }
        public HttpResponseMessage GetResponse(string url)
        {
            url = Client.BaseAddress.ToString() + url;
            return Client.GetAsync(url).Result;
        }
        public HttpResponseMessage PutResponse(string url, object model)
        {
            url = Client.BaseAddress.ToString() + url;
            var content = new StringContent(JsonConvert.SerializeObject(model), System.Text.Encoding.UTF8, "application/json");
            var result = Client.PutAsync(url, content).Result;
            return result;
        }
        public HttpResponseMessage PostResponse(string url, object model)
        {
            url = Client.BaseAddress.ToString() + url;
            var content = new StringContent(JsonConvert.SerializeObject(model), System.Text.Encoding.UTF8, "application/json");
            var result = Client.PostAsync(url, content).Result;
            return result;
        }
        public HttpResponseMessage DeleteResponse(string url)
        {
            url = Client.BaseAddress.ToString() + url;
            return Client.DeleteAsync(url).Result;
        }
    }
}



