﻿using LiteDB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using SingleStoneApplication.Models;
using Newtonsoft.Json;
using System.Configuration;

namespace SingleStoneApplication.Controllers
{
    public class ContactController : ApiController
    {
        // GET: api/Contact
        public string liteDBPath = ConfigurationManager.AppSettings["LiteDBPath"];
        public string Get()
        {
            using (var db = new LiteDatabase(liteDBPath))
            {

                var customers = db.GetCollection<ContactModel>("contacts");

                return JsonConvert.SerializeObject(customers.FindAll().ToList());
            }

        }

        // GET: api/Contact/5
        public string Get(int id)
        {
            using (var db = new LiteDatabase(liteDBPath))
            {
                var customers = db.GetCollection<ContactModel>("contacts");
                return JsonConvert.SerializeObject(customers.FindAll().Where(a => a.Id == id).FirstOrDefault());


            }
        }

        // POST: api/Contact
        public void Post([FromBody]ContactModel model)
        {
            using (var db = new LiteDatabase(liteDBPath))
            {
                var collection = db.GetCollection<ContactModel>("contacts");

                collection.Insert(model);
            }
        }

        // PUT: api/Contact/5
        public bool Put([FromBody]ContactModel model)
        {
            using (var db = new LiteDatabase(liteDBPath))
            {
                var collection = db.GetCollection<ContactModel>("contacts");

                return collection.Update(model);
            }
        }

        // DELETE: api/Contact/5
        public bool Delete(int id)
        {
            using (var db = new LiteDatabase(liteDBPath))
            {
                var collection = db.GetCollection<ContactModel>("contacts");

                return collection.Delete(id);
            }
        }
    }
}

