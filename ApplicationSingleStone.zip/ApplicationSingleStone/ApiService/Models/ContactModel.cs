﻿
using LiteDB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SingleStoneApplication.Models
{
    public class ContactModel
    {
        public NameModel Names { get; set; }
        public AddressModel Address { get; set; }
        public PhoneModel Phones { get; set; }
        public string Email { get; set; }

        [BsonId]
        public int Id { get; set; }
    }
    public class NameModel
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string MiddleName { get; set; }
    }
    public class AddressModel
    {
        public string Street { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
    }

    public class PhoneModel
    {
        public string Number { get; set; }
        public string Type { get; set; }
    }
}








